class TodoApp {
    constructor() {
        this.tasks = JSON.parse(localStorage.getItem('todo-tasks')) || [];
        this.taskInput = document.getElementById('taskInput');
        this.taskList = document.getElementById('taskList');
        this.stats = document.getElementById('stats');
        this.todoForm = document.getElementById('todoForm');
        this.clearCompletedBtn = document.getElementById('clearCompleted');
        this.clearAllBtn = document.getElementById('clearAll');
        
        this.init();
    }

    init() {
        this.render();
        this.updateStats();
        this.bindEvents();
    }

    bindEvents() {
        this.todoForm.addEventListener('submit', (e) => {
            e.preventDefault();
            this.addTask();
        });

        this.clearCompletedBtn.addEventListener('click', () => this.clearCompletedTasks());
        this.clearAllBtn.addEventListener('click', () => this.clearAllTasks());
    }

    addTask() {
        const text = this.taskInput.value.trim();
        if (text) {
            const task = {
                id: Date.now(),
                text,
                completed: false,
                createdAt: new Date().toISOString()
            };
            
            this.tasks.unshift(task); // Ajoute en haut
            this.taskInput.value = '';
            this.save();
            this.render();
            this.updateStats();
        }
    }

    toggleTask(id) {
        this.tasks = this.tasks.map(task => 
            task.id === id 
                ? { ...task, completed: !task.completed }
                : task
        );
        this.save();
        this.render();
        this.updateStats();
    }

    deleteTask(id) {
        this.tasks = this.tasks.filter(task => task.id !== id);
        this.save();
        this.render();
        this.updateStats();
    }

    clearCompletedTasks() {
        this.tasks = this.tasks.filter(task => !task.completed);
        this.save();
        this.render();
        this.updateStats();
    }

    clearAllTasks() {
        if (confirm('Supprimer TOUTES les tâches ?')) {
            this.tasks = [];
            this.save();
            this.render();
            this.updateStats();
        }
    }

    render() {
        this.taskList.innerHTML = this.tasks.map(task => `
            <li class="task-item ${task.completed ? 'completed' : ''}">
                <input type="checkbox" class="task-checkbox" 
                       ${task.completed ? 'checked' : ''} 
                       onchange="todoApp.toggleTask(${task.id})">
                <span class="task-text ${task.completed ? 'completed' : ''}"
                      ondblclick="todoApp.toggleTask(${task.id})">
                    ${task.text}
                </span>
                <button class="delete-btn" onclick="todoApp.deleteTask(${task.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </li>
        `).join('');
    }

    updateStats() {
        const remaining = this.tasks.filter(task => !task.completed).length;
        const total = this.tasks.length;
        this.stats.textContent = `${remaining} / ${total} tâche${total !== 1 ? 's' : ''} restante${remaining !== 1 ? 's' : ''}`;
    }

    save() {
        localStorage.setItem('todo-tasks', JSON.stringify(this.tasks));
    }
}

// Initialisation globale
const todoApp = new TodoApp();